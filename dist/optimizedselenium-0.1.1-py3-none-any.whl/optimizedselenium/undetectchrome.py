import undetected_chromedriver.v2 as uc
driver = uc.Chrome()
with driver:
    driver.get('https://freecoursesite.com')